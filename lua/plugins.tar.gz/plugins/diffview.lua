return {
	"sindrets/diffview.nvim",
}
